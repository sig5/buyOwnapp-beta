package com.example.myapplication;

import java.util.ArrayList;

public class MyData {
    static ArrayList<String> name =new ArrayList<String>();
    static ArrayList<String> price = new ArrayList<String>();
    static ArrayList<String> description = new ArrayList<String>();
    static ArrayList<String> authorname = new ArrayList<String>();
    static ArrayList<String> image =new ArrayList<String>();
    static int p=0;


}
